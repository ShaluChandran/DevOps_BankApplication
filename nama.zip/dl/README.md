# DI-WSL
To Convert JSON to ORC
